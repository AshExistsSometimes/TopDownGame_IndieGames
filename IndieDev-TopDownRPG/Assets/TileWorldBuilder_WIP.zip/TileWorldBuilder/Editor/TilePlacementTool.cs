using UnityEditor;
using UnityEngine;

[InitializeOnLoad]
public static class TilePlacementTool
{
    static TilePlacementTool()
    {
        SceneView.duringSceneGui += DuringSceneGUI;
    }

    static bool active;
    static TileWorldData world;

    static TileShape shape;
    static int rotation;
    static int groundMat;
    static int cliffMat;

    static Vector3Int lastGrid;

    public static void SetState(
        bool toolActive,
        TileWorldData worldData,
        TileShape s,
        int rot,
        int gMat,
        int cMat)
    {
        active = toolActive;
        world = worldData;
        shape = s;
        rotation = rot;
        groundMat = gMat;
        cliffMat = cMat;
    }

    static void DuringSceneGUI(SceneView scene)
    {
        /*
         * TOOL ACTIVE CHECK
         * -----------------
         * If the editor window disabled the tool
         * or we have no world data assigned,
         * do nothing.
         */

        if (!active || world == null)
            return;

        Event e = Event.current;

        DrawGrid();

        /*
         * RAYCAST FROM MOUSE INTO SCENE
         */
        Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);

        RaycastHit hit;

        Plane plane = new Plane(Vector3.up, 0);

        float dist;

        Vector3Int ghostGrid;

        if (plane.Raycast(ray, out dist))
        {
            Vector3 hit = ray.GetPoint(dist);

            ghostGrid = SnapToGrid(hit);
        }
        else
        {
            return;
        }

        /*
         * We raycast against colliders.
         * These colliders come from the chunk meshes.
         */

        if (Physics.Raycast(ray, out hit, 500f))
        {
            Vector3Int tilePos = Vector3Int.RoundToInt(hit.point - hit.normal * 0.5f);

            /*
             * RIGHT CLICK = DELETE TILE
             */

            if (e.type == EventType.MouseDown && e.button == 1)
            {
                world.RemoveTile(tilePos);

                e.Use();
            }

            /*
             * LEFT CLICK = PLACE ADJACENT TILE
             */

            if (e.type == EventType.MouseDown && e.button == 0)
            {
                Vector3Int placePos =
                    Vector3Int.RoundToInt(hit.point + hit.normal * 0.5f);

                PlaceTile(placePos);

                e.Use();
            }

            /*
             * VISUAL DEBUG
             */

            Handles.color = Color.yellow;
            Handles.DrawWireCube(tilePos, Vector3.one);
        }

        /*
         * SHAPE SWITCHING
         */

        if (e.type == EventType.ScrollWheel)
        {
            int shapeCount = System.Enum.GetValues(typeof(TileShape)).Length;

            int newIndex = ((int)shape + (e.delta.y > 0 ? 1 : -1));

            if (newIndex < 0)
                newIndex = shapeCount - 1;

            if (newIndex >= shapeCount)
                newIndex = 0;

            shape = (TileShape)newIndex;

            e.Use();
        }

        /*
         * ROTATION
         */

        if (e.type == EventType.KeyDown && e.keyCode == KeyCode.R)
        {
            if (e.shift)
                rotation -= 90;
            else
                rotation += 90;

            e.Use();
        }
    }

    static void PlaceTile(Vector3Int grid)
    {
        TileData tile = new TileData();

        tile.shape = shape;
        tile.rotation = rotation;
        tile.groundMaterial = groundMat;
        tile.cliffMaterial = cliffMat;

        world.SetTile(grid, tile);
    }

    static void DeleteTile(Vector3Int grid)
    {
        world.RemoveTile(grid);
    }

    static void DrawGrid()
    {
        Handles.color = new Color(0.6f, 0.6f, 0.6f, 0.2f);

        int size = 100;

        for (int x = -size; x <= size; x++)
        {
            Handles.DrawLine(
                new Vector3(x, 0, -size),
                new Vector3(x, 0, size));
        }

        for (int z = -size; z <= size; z++)
        {
            Handles.DrawLine(
                new Vector3(-size, 0, z),
                new Vector3(size, 0, z));
        }
    }

    static void DrawGhostTile(Vector3 position)
    {
        Handles.color = new Color(0, 1, 0, 0.3f);

        Matrix4x4 matrix =
            Matrix4x4.TRS(
                position,
                Quaternion.Euler(0, rotation, 0),
                Vector3.one);

        using (new Handles.DrawingScope(matrix))
        {
            Handles.CubeHandleCap(
                0,
                Vector3.zero,
                Quaternion.identity,
                1,
                EventType.Repaint);
        }
    }
    static Vector3Int SnapToGrid(Vector3 pos)
    {
        return new Vector3Int(
            Mathf.FloorToInt(pos.x),
            Mathf.FloorToInt(pos.y),
            Mathf.FloorToInt(pos.z)
        );
    }

}