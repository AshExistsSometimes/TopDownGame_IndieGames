using UnityEditor;
using UnityEngine;
using System.Collections.Generic;

public class TileWorldEditorWindow : EditorWindow
{
    bool ActivateGrid = true;

    TileShape selectedShape;

    int rotation;

    int groundIndex;
    int cliffIndex;

    TileWorldData world;

    public List<Material> groundMaterials = new List<Material>();
    public List<Material> cliffMaterials = new List<Material>();

    PreviewRenderUtility preview;

    Vector2 previewRotation;

    [MenuItem("Tools/Tile World Builder")]
    static void Open()
    {
        GetWindow<TileWorldEditorWindow>();
    }

    void OnEnable()
    {
        preview = new PreviewRenderUtility();
    }

    void OnGUI()
    {
        ActivateGrid =
            EditorGUILayout.Toggle("Activate Grid", ActivateGrid);

        selectedShape =
            (TileShape)EditorGUILayout.EnumPopup("Tile Shape", selectedShape);

        rotation =
            EditorGUILayout.IntField("Rotation", rotation);

        DrawMaterialLists();

        EditorGUILayout.Space(10);

        world = (TileWorldData)EditorGUILayout.ObjectField(
        "World Data",
        world,
        typeof(TileWorldData),
        true);

        if (world == null)
        {
            EditorGUILayout.HelpBox(
                "Assign a TileWorldData object from the scene.",
                MessageType.Warning);

            return;
        }

        GUILayout.Space(10);


        DrawPreview();

        GUILayout.Space(10);

        if (GUILayout.Button("Combine Meshes (Build Chunks)"))
        {
            TileMeshBaker.BuildChunks(world);
        }

        TilePlacementTool.SetState(
            ActivateGrid,
            world,
            selectedShape,
            rotation,
            groundIndex,
            cliffIndex
        );

        DrawControls();
    }

    void DrawMaterialLists()
    {
        GUILayout.Label("Ground Materials");

        int removeIndex = -1;

        for (int i = 0; i < groundMaterials.Count; i++)
        {
            EditorGUILayout.BeginHorizontal();

            groundMaterials[i] =
                (Material)EditorGUILayout.ObjectField(
                    groundMaterials[i],
                    typeof(Material),
                    false);

            if (GUILayout.Button("X", GUILayout.Width(20)))
                removeIndex = i;

            EditorGUILayout.EndHorizontal();
        }

        if (removeIndex >= 0)
            groundMaterials.RemoveAt(removeIndex);

        if (GUILayout.Button("Add Ground Material"))
            groundMaterials.Add(null);


        GUILayout.Space(10);
        GUILayout.Label("Cliff Materials");

        removeIndex = -1;

        for (int i = 0; i < cliffMaterials.Count; i++)
        {
            EditorGUILayout.BeginHorizontal();

            cliffMaterials[i] =
                (Material)EditorGUILayout.ObjectField(
                    cliffMaterials[i],
                    typeof(Material),
                    false);

            if (GUILayout.Button("X", GUILayout.Width(20)))
                removeIndex = i;

            EditorGUILayout.EndHorizontal();
        }

        if (removeIndex >= 0)
            cliffMaterials.RemoveAt(removeIndex);

        if (GUILayout.Button("Add Cliff Material"))
            cliffMaterials.Add(null);
    }

    void DrawControls()
    {
        GUILayout.Space(10);

        EditorGUILayout.HelpBox(
            "Controls\n" +
            "Left Click = Place\n" +
            "Right Click = Delete\n" +
            "Scroll = Change Shape\n" +
            "R / Shift+R = Rotate",
            MessageType.Info
        );
    }

    void DrawPreview()
    {
        Rect rect = GUILayoutUtility.GetRect(230, 230);


        if (Event.current.type == EventType.MouseDrag &&
        rect.Contains(Event.current.mousePosition))
        {
            previewRotation.x += Event.current.delta.x;
            previewRotation.y -= Event.current.delta.y;

            Event.current.Use();
        }

        preview.BeginPreview(rect, GUIStyle.none);

        Mesh mesh = GetPreviewMesh();

        preview.camera.transform.position = new Vector3(3.7f, 3.7f, -3.7f);
        preview.camera.transform.LookAt(Vector3.zero);

        preview.lights[0].intensity = 1;

        preview.DrawMesh(mesh, Matrix4x4.identity,
            groundMaterials.Count > 0 ?
            groundMaterials[groundIndex] : null,
            0);

        preview.camera.Render();

        Texture result = preview.EndPreview();

        GUI.DrawTexture(rect, result);
    }

    Mesh GetPreviewMesh()
    {
        return Resources.GetBuiltinResource<Mesh>("Cube.fbx");
    }
}