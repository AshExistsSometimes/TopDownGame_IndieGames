using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public static class TileMeshBaker
{
    static readonly Vector3[] faceDirections =
    {
        Vector3.right,
        Vector3.left,
        Vector3.forward,
        Vector3.back,
        Vector3.up,
        Vector3.down
    };

    public static void BuildChunks(TileWorldData world)
    {
        if (world == null) return;

        Transform chunkRoot = GetOrCreate(world.transform, "Chunks");

        Dictionary<Vector2Int, List<Vector3Int>> chunkTiles =
            new Dictionary<Vector2Int, List<Vector3Int>>();

        foreach (var kvp in world.tiles)
        {
            Vector3Int pos = kvp.Key;

            Vector2Int chunk =
                TileChunkUtility.GetChunk(pos);

            if (!chunkTiles.ContainsKey(chunk))
                chunkTiles[chunk] = new List<Vector3Int>();

            chunkTiles[chunk].Add(pos);
        }

        foreach (var chunk in chunkTiles)
        {
            BuildChunk(world, chunk.Key, chunk.Value, chunkRoot);
        }

        Debug.Log("Chunk baking complete");
    }

    static void BuildChunk(
        TileWorldData world,
        Vector2Int chunkCoord,
        List<Vector3Int> tiles,
        Transform root)
    {
        List<Vector3> verts = new List<Vector3>();
        List<int> tris = new List<int>();

        foreach (var tilePos in tiles)
        {
            TileData tile = world.tiles[tilePos];

            AddCube(tilePos, world, verts, tris);
        }

        Mesh mesh = new Mesh();

        mesh.indexFormat =
            UnityEngine.Rendering.IndexFormat.UInt32;

        mesh.SetVertices(verts);
        mesh.SetTriangles(tris, 0);

        mesh.RecalculateNormals();

        string name =
            "Chunk_" + chunkCoord.x + "_" + chunkCoord.y;

        Transform existing =
            root.Find(name);

        if (existing != null)
            Object.DestroyImmediate(existing.gameObject);

        GameObject go =
            new GameObject(name);

        go.transform.parent = root;

        MeshFilter mf =
            go.AddComponent<MeshFilter>();

        MeshRenderer mr =
            go.AddComponent<MeshRenderer>();

        MeshCollider mc =
            go.AddComponent<MeshCollider>();

        mf.sharedMesh = mesh;
        mc.sharedMesh = mesh;

        GameObjectUtility.SetStaticEditorFlags(
            go,
            StaticEditorFlags.BatchingStatic |
            StaticEditorFlags.OccluderStatic |
            StaticEditorFlags.NavigationStatic
        );
    }

    static void AddCube(
        Vector3Int pos,
        TileWorldData world,
        List<Vector3> verts,
        List<int> tris)
    {
        for (int i = 0; i < 6; i++)
        {
            Vector3Int neighbor =
                pos + Vector3Int.RoundToInt(faceDirections[i]);

            if (world.tiles.ContainsKey(neighbor))
                continue;

            AddFace(pos, i, verts, tris);
        }
    }

    static void AddFace(
        Vector3 pos,
        int face,
        List<Vector3> verts,
        List<int> tris)
    {
        int start = verts.Count;

        switch (face)
        {
            case 0: // right
                verts.Add(pos + new Vector3(1, 0, 0));
                verts.Add(pos + new Vector3(1, 1, 0));
                verts.Add(pos + new Vector3(1, 1, 1));
                verts.Add(pos + new Vector3(1, 0, 1));
                break;

            case 1: // left
                verts.Add(pos + new Vector3(0, 0, 1));
                verts.Add(pos + new Vector3(0, 1, 1));
                verts.Add(pos + new Vector3(0, 1, 0));
                verts.Add(pos + new Vector3(0, 0, 0));
                break;

            case 2: // forward
                verts.Add(pos + new Vector3(1, 0, 1));
                verts.Add(pos + new Vector3(1, 1, 1));
                verts.Add(pos + new Vector3(0, 1, 1));
                verts.Add(pos + new Vector3(0, 0, 1));
                break;

            case 3: // back
                verts.Add(pos + new Vector3(0, 0, 0));
                verts.Add(pos + new Vector3(0, 1, 0));
                verts.Add(pos + new Vector3(1, 1, 0));
                verts.Add(pos + new Vector3(1, 0, 0));
                break;

            case 4: // top
                verts.Add(pos + new Vector3(0, 1, 0));
                verts.Add(pos + new Vector3(0, 1, 1));
                verts.Add(pos + new Vector3(1, 1, 1));
                verts.Add(pos + new Vector3(1, 1, 0));
                break;

            case 5: // bottom
                verts.Add(pos + new Vector3(0, 0, 1));
                verts.Add(pos + new Vector3(0, 0, 0));
                verts.Add(pos + new Vector3(1, 0, 0));
                verts.Add(pos + new Vector3(1, 0, 1));
                break;
        }

        tris.Add(start);
        tris.Add(start + 1);
        tris.Add(start + 2);

        tris.Add(start);
        tris.Add(start + 2);
        tris.Add(start + 3);
    }

    static Transform GetOrCreate(Transform root, string name)
    {
        Transform t = root.Find(name);

        if (t == null)
        {
            GameObject go = new GameObject(name);
            go.transform.parent = root;
            t = go.transform;
        }

        return t;
    }

    public static void ClearPreview()
    {
        GameObject preview =
            GameObject.Find("TilePreview");

        if (preview != null)
            Object.DestroyImmediate(preview);
    }
}
