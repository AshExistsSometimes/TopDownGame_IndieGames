using UnityEngine;

public enum TileShape
{
    Cube,
    Slope45,
    Corner45
}