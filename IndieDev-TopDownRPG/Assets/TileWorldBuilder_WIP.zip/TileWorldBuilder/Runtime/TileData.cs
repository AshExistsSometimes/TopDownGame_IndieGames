using UnityEngine;

[System.Serializable]
public class TileData
{
    public TileShape shape;

    public int rotation;

    public int groundMaterial;

    public int cliffMaterial;

    public string tag;
}