using UnityEngine;

public static class TileChunkUtility
{
    public const int CHUNK_SIZE = 16;

    public static Vector2Int GetChunk(Vector3Int tile)
    {
        return new Vector2Int(
            Mathf.FloorToInt(tile.x / (float)CHUNK_SIZE),
            Mathf.FloorToInt(tile.z / (float)CHUNK_SIZE)
        );
    }
}
