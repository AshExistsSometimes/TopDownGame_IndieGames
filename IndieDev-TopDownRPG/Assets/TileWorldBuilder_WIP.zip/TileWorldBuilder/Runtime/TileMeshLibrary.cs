using UnityEngine;

/*
 * TileMeshLibrary
 *
 * Provides meshes used by the tile system.
 * These are used by:
 *
 * - preview window
 * - ghost tile
 * - mesh baker
 *
 * Right now we generate them procedurally.
 */

public static class TileMeshLibrary
{
    static Mesh cube;
    static Mesh slope45;
    static Mesh corner45;

    public static Mesh GetMesh(TileShape shape)
    {
        switch (shape)
        {
            case TileShape.Slope45:
                return GetSlope45();

            case TileShape.Corner45:
                return GetCorner45();

            default:
                return GetCube();
        }
    }

    /*
     * Standard 1x1x1 cube
     */
    static Mesh GetCube()
    {
        if (cube != null)
            return cube;

        cube = Resources.GetBuiltinResource<Mesh>("Cube.fbx");

        return cube;
    }

    /*
     * 45� ramp
     */
    static Mesh GetSlope45()
    {
        if (slope45 != null)
            return slope45;

        slope45 = new Mesh();

        Vector3[] v =
        {
            new Vector3(0,0,0),
            new Vector3(1,0,0),
            new Vector3(1,0,1),
            new Vector3(0,0,1),

            new Vector3(0,1,1),
            new Vector3(1,1,1)
        };

        int[] t =
        {
            0,1,2,
            0,2,3,

            3,2,4,
            2,5,4,

            0,3,4,
            0,4,1,

            1,4,5,
            1,5,2
        };

        slope45.vertices = v;
        slope45.triangles = t;
        slope45.RecalculateNormals();

        return slope45;
    }

    /*
     * 45� corner ramp
     */
    static Mesh GetCorner45()
    {
        if (corner45 != null)
            return corner45;

        corner45 = new Mesh();

        Vector3[] v =
        {
            new Vector3(0,0,0),
            new Vector3(1,0,0),
            new Vector3(1,0,1),
            new Vector3(0,0,1),

            new Vector3(1,1,1)
        };

        int[] t =
        {
            0,1,2,
            0,2,3,

            2,4,3,
            1,4,2
        };

        corner45.vertices = v;
        corner45.triangles = t;
        corner45.RecalculateNormals();

        return corner45;
    }
}