using System.Collections.Generic;
using UnityEngine;

public class TileWorldData : MonoBehaviour
{
    public Dictionary<Vector3Int, TileData> tiles = new Dictionary<Vector3Int, TileData>();

    public void SetTile(Vector3Int pos, TileData tile)
    {
        tiles[pos] = tile;
    }

    public bool TryGetTile(Vector3Int pos, out TileData tile)
    {
        return tiles.TryGetValue(pos, out tile);
    }

    public void RemoveTile(Vector3Int pos)
    {
        if (tiles.ContainsKey(pos))
            tiles.Remove(pos);
    }
}